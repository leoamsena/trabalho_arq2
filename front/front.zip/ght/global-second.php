<?php
/*
include("../../back/ght.php");
$n = $_POST['n'];
$m = $_POST['m'];
$g = $_POST['g'];



$trace = explode("\n", file_get_contents($_FILES['trace']['tmp_name']));
$json = ght($n, $m, $g, $trace);

echo $json;
*/
echo "cheguei";
